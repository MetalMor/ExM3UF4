package herenciaMultiple;

/**
 *
 * 051115
 * @author mor
 */
public interface MilitarInterface {
    
    public String getGrau();
    
    public void setGrau(String g);
    
}
