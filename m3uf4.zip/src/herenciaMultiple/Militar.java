package herenciaMultiple;

/**
 *
 * 051115
 * @author mor
 */
public class Militar {
    
    private String grau;
    
    public String getGrau() {
        return grau;
    }
    
    public void setGrau(String g) {
        grau = g;
    }
    
}
