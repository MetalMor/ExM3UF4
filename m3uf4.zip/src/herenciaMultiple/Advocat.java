package herenciaMultiple;

/**
 *
 * 051115
 * @author mor
 */
public class Advocat {
    
    private String tribunal;
    
    public String getTribunal() {
        return tribunal;
    }
    
    public void setTribunal(String t) {
        tribunal = t;
    }
    
}
