package ex08;

/**
 * 
 * 161015
 * @author mor
 */
public class Principal {
    
    public static void main (String[] args) {
        
        Alumne a1 = new Alumne();
        
    }
    
}
