package herencia;

/**
 * 221015
 * @author mor
 */
public abstract class Persona {
    private String nom;
    
    public abstract String mostrarDades();
    
}
