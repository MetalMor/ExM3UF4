package ex06;

/**
 * 091015
 * @author mor
 */
public class DNI {
    
    protected int numero;
    
    public int getDNI() {
        
        return numero;
        
    }
    
    public void setDNI(int num) {
        
        numero = num;
        
    }
    
}
